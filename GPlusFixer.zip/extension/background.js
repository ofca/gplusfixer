(function(window) {
    window.addEventListener('DOMContentLoaded', function(event) {

        var STYLES = '',
            keys = ['removeScrolls', 'fullPostContent', 'fullCommentContent', 'commentBoxHeight', 'defaultFont', 'fontSize', 'slimNav'];

        // Load settings
        chrome.storage.sync.get(keys, function(item) {
            if (item.removeScrolls) {
                /* Notification window scroll */
                /* First expression is for normal post, second is for post in notification window */
                STYLES += ".CLSMk { max-height: none !important; }\n";
                STYLES += ".qf.ii.wv4ec.r6Rtbe .CLSMk { max-height: 100px !important; }\n"
            }

            if (item.fullPostContent) {
                /* post content */
                STYLES += ".WamaFb.DIcL3e { max-height: inherit !important; }\n"; 

                /* "read more" button in post */
                STYLES += ".a-n.fE.syxni.JBNexc { display: none !important; }\n";
            }

            if (item.fullCommentContent) {
                /* comment content */
                STYLES += ".Mi.Vp.WamaFb.Gw.Gm { max-height: none !important; }\n";

                /* comment "read more" */
                STYLES += ".a-n.wj.syxni.unQkyd[role=button], .a-n.vj.unQkyd[role=button] { display: none !important; }";
            }

            if (item.commentBoxHeight) {
                /* comment textarea */
                STYLES += ".yd.editable[role=textbox] { max-height: "+item.commentBoxHeight+"px !important; }\n";
            }

            if (item.defaultFont) {
                STYLES += "body { font-family: '"+item.defaultFont+"' !important; }\n";
            }

            if (item.fontSize) {
                STYLES += "body, .vFgtwf { font-size: "+item.fontSize+"px !important; }\n";
            }

            if (item.slimNav) {
                STYLES += ""
                    + ".FVPtwe { -webkit-transition: none !important; transition: none !important; }"
                    + ".cInFec { -webkit-transition: none !important; transition: none !important; }"
                    + ".wH3YRe { margin-left: 0 !important; overflow: visible !important; width: 50px !important; padding-left: 0 !important; }"

                    /* labels */
                    + ".A9a.bOa { display: none !important; }"
                    /* span */
                    + ".hAmwye { display: none !important; }"

                    /* links */
                    + ".cS.xWa > a { height: 34px !important; padding-left: 15px !important; }"
                    /* hover on link */
                    + ".cS.xWa > a:hover { background: none !important; }"
                    + ".cS.xWa:hover .A9a.bOa { display: inline !important; position: absolute !important; z-index: 9999 !important; border-radius: 5px !important; background: #fff !important; padding: 4px 10px !important; }"

                    /* footer */
                    + ".lZkdDe.pFZ7Ne { display: none !important; }"

                    + "#contentPage { margin-left: 60px !important; }"

                    /* header with page title */
                    + ".IvwRoc.Um8btf { left: 50px !important; }"
            }

            var styleElement = document.createElement("style");
            styleElement.setAttribute("id", "gplusfixer");
            styleElement.setAttribute("class", "gplusfixer");
            styleElement.setAttribute("type", "text/css");
            styleElement.appendChild(document.createTextNode(STYLES));
            if (document.head) {
                document.head.appendChild(styleElement);
            } else {
                document.documentElement.appendChild(styleElement);
            }
        });
    });
})(window);
